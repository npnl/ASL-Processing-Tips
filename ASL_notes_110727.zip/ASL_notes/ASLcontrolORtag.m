% How to determine if tag is first for ASL data...
% 1. Extract timecourse in bash with fsl: fslmeants -i INPUT.nii.gz -o ORDER.txt
% 2. Open Order.txt; Delete first point (if M0); then make vector tc=[]'; to insert timecourse
% array into matlab
% 3. Set user inputs here and run this program
% 
% This is super simple and messy! Don't judge. :) 
% Sook-Lei Liew, sliew at usc dot edu || 2011.07.20



%% User Inputs
TRs=170; %e.g. actually 171 but M0 is first volume so deleted
%tc=[]'; %can input timecourse here if not already done

%% Separate Even/Odd

a=(1:2:TRs)';  %odds
b=(2:2:TRs)';  %evens 

odds=[];  %first condition
evens=[];  

for i=1:length(a)
    odds=[odds tc(a(i))];
end

for i=1:length(b)
    evens=[evens tc(b(i))];
end

%odds=odds';
%evens=evens';

oddFirst=odds-evens;
oddVal=mean(oddFirst);

evenFirst=evens-odds;
evenVal=mean(evenFirst);

fprintf('mean of odd numbers: %1.4f \n',oddVal);
fprintf('mean of even numbers: %1.4f \n',evenVal);
plot(tc(1:10));     %just to visualize/double check; control image is higher intensity!

if (oddVal>0)
    fprintf('The first timepoint is control \n\n')
elseif (evenVal>0)
    fprintf('The first timepoint is tag \n\n')
else
    fprintf('error! \n\n')
end

