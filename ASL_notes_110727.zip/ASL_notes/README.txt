CONTENTS:
ASL_FEAT_notes.txt - brief notes on setting parameters for task-related ASL in FEAT

ASLcontrolORtag.m - matlab script to tell you if control or tag is first volume (see comments in script for usage)

FSL_Feat_ASL_Perfusion_Guide.pdf - just a pdf copy of the FSL website for running ASL analyses

Tips_for_Processing_ASL_Data.pdf - a longer version of tips and hints for processing ASL data, particularly using MELODIC for denoising. Good for resting state data!

Also, an ASL/BOLD overlap map is coming shortly!

Email sliew@usc.edu if questions or comments.
